test_that("clustering phenotyping vignette documents every implemented workflow", {
  vignette_path <- testthat::test_path("..", "..", "vignettes", "ClusteringPhenotyping.qmd")
  testthat::skip_if_not(file.exists(vignette_path))

  vignette_text <- paste(readLines(vignette_path, warn = FALSE), collapse = "\n")
  expect_match(vignette_text, "CreateClusterModel_SOM_MClust")
  expect_match(vignette_text, "CreateClusterModel_MClust")
  expect_match(vignette_text, "CreateClusterModel_KMeans")
  expect_match(vignette_text, "CreateClusterModel_HDBSCAN")
  expect_match(vignette_text, "CreateClusterModel_Gower_PAM")
  expect_match(vignette_text, "CreateClusterModel_LatentClass")
  expect_match(vignette_text, "CreateClusterModel_MCA_MClust")
  expect_match(vignette_text, "ProjectCluster")
})
