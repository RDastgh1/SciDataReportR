#' Plot categorical distributions
#'
#' This function creates plots to visualize the distributions of categorical
#' variables in a dataframe.
#'
#' @param data The dataframe containing the variables to be plotted.
#' @param variables Optional. A character vector specifying the names of the
#'   categorical variables to be plotted. If NULL, categorical variables are
#'   automatically detected.
#' @param Relabel Logical. If TRUE, missing labels in the dataframe are replaced
#'   with column names as labels for plotting.
#' @param TreatOrdinalAs How ordinal variables are handled. This categorical
#' plot accepts `"Categorical"` or `"Exclude"`.
#' @param Ordinal Deprecated logical compatibility option; use
#' `TreatOrdinalAs` instead.
#' @param LabelType Character. Either "percent" or "count", indicating what
#'   should be shown on the x-axis and inside the bars.
#' @param MissingLabel Character label to use for missing values.
#'
#' @return A ggplot object visualizing the distributions of categorical variables.
#' @importFrom sjlabelled get_label
#' @importFrom magrittr %>%
#' @param DataFrame \strong{Deprecated} (since 19.15.0). Use \code{data} instead.
#' @param Variables \strong{Deprecated} (since 19.15.0). Use \code{variables} instead.
#' @examples
#' data(SampleData)
#' data(SampleVariableTypes)
#'
#' Labelled <- RevalueData(SampleData, SampleVariableTypes)$RevaluedData
#'
#' PlotCategoricalDistributions(
#'   Labelled,
#'   variables = c("Diagnosis", "Genotype")
#' )
#' @export
PlotCategoricalDistributions <- function(data,
    variables = NULL,
    Relabel = TRUE,
    Ordinal = lifecycle::deprecated(),
    TreatOrdinalAs = "Categorical",
    LabelType = "percent",
    MissingLabel = "Missing",
    DataFrame = lifecycle::deprecated(),
    Variables = lifecycle::deprecated()) {
  # Deprecated argument shims (SciDataReportR 19.15.0)
  if (lifecycle::is_present(DataFrame)) {
    lifecycle::deprecate_warn("19.15.0", "PlotCategoricalDistributions(DataFrame)", "PlotCategoricalDistributions(data)")
    data <- DataFrame
  }
  if (!missing(data)) DataFrame <- data
  if (lifecycle::is_present(Variables)) {
    lifecycle::deprecate_warn("19.15.0", "PlotCategoricalDistributions(Variables)", "PlotCategoricalDistributions(variables)")
    variables <- Variables
  }
  Variables <- variables

  if (lifecycle::is_present(Ordinal)) {
    lifecycle::deprecate_warn("20.20.0", "PlotCategoricalDistributions(Ordinal)", "PlotCategoricalDistributions(TreatOrdinalAs)")
    TreatOrdinalAs <- if (isTRUE(Ordinal)) "Categorical" else "Exclude"
  }
  TreatOrdinalAs <- match.arg(TreatOrdinalAs, c("Categorical", "Continuous", "Both", "Exclude"))
  if (TreatOrdinalAs %in% c("Continuous", "Both")) {
    stop("PlotCategoricalDistributions() requires TreatOrdinalAs = 'Categorical' or 'Exclude'.", call. = FALSE)
  }


  # Validate inputs

  if (!is.data.frame(DataFrame)) {
    stop("`DataFrame` must be a data frame.")
  }

  if (is.null(Variables)) {
    Variables <- getCatVars(DataFrame)
  }

  if (!is.character(Variables)) {
    stop("`Variables` must be a character vector.")
  }

  missing_vars <- setdiff(Variables, colnames(DataFrame))
  if (length(missing_vars) > 0) {
    stop("Variables not found in DataFrame: ", paste(missing_vars, collapse = ", "))
  }

  if (!is.logical(Relabel) || length(Relabel) != 1 || is.na(Relabel)) {
    stop("`Relabel` must be TRUE or FALSE.")
  }

  if (!LabelType %in% c("percent", "count")) {
    stop("`LabelType` must be either 'percent' or 'count'.")
  }

  if (!is.character(MissingLabel) || length(MissingLabel) != 1 || is.na(MissingLabel)) {
    stop("`MissingLabel` must be a single character value.")
  }

  # Prepare data

  ordinal <- ConvertOrdinalToNumeric(
    DataFrame, Variables, TreatOrdinalAs = TreatOrdinalAs,
    ReturnMetadata = TRUE
  )
  DataFrame <- ordinal$data
  Variables <- ordinal$variables

  if (length(Variables) == 0) {
    stop("No variables available to plot.")
  }

  if (Relabel) {
    DataFrame <- ReplaceMissingLabels(DataFrame)

    facetlabels <- sjlabelled::get_label(
      DataFrame %>% dplyr::select(dplyr::all_of(Variables))
    )

    names(facetlabels) <- NULL
    facetlabels[is.na(facetlabels) | facetlabels == ""] <- Variables[is.na(facetlabels) | facetlabels == ""]
  } else {
    facetlabels <- Variables
  }

  plot_df <- purrr::map_dfr(Variables, function(var) {
    x <- DataFrame[[var]]

    if (is.factor(x) || is.integer(x) || is.logical(x) ||
        inherits(x, "Date") || inherits(x, "POSIXt")) {
      x <- as.character(x)
    }

    tibble::tibble(
      VariableRaw = var,
      Level = x
    ) %>%
      dplyr::mutate(
        Level = as.character(Level),
        Level = tidyr::replace_na(Level, MissingLabel)
      ) %>%
      dplyr::count(VariableRaw, Level, name = "n") %>%
      dplyr::group_by(VariableRaw) %>%
      dplyr::mutate(
        prop = n / sum(n)
      ) %>%
      dplyr::ungroup()
  })

  # Order levels within each variable so Missing is semantically last
  plot_df <- plot_df %>%
    dplyr::mutate(
      IsMissing = Level == MissingLabel
    ) %>%
    dplyr::group_by(VariableRaw) %>%
    dplyr::arrange(IsMissing, dplyr::desc(prop), .by_group = TRUE) %>%
    dplyr::mutate(
      stack_id = dplyr::row_number()
    ) %>%
    dplyr::ungroup()

  # Create unique fill keys so each variable can have its own within-bar order
  plot_df <- plot_df %>%
    dplyr::mutate(
      Variable = factor(VariableRaw, levels = Variables, labels = facetlabels),
      FillKey = paste0(VariableRaw, "___", Level)
    )

  fill_key_order <- plot_df %>%
    dplyr::arrange(Variable, stack_id) %>%
    dplyr::pull(FillKey)

  plot_df <- plot_df %>%
    dplyr::mutate(
      FillKey = factor(FillKey, levels = fill_key_order),
      Value = if (LabelType == "percent") prop else n,
      Label = dplyr::case_when(
        LabelType == "percent" & prop >= 0.04 ~ paste0(Level, "\n", scales::percent(prop, accuracy = 1)),
        LabelType == "count" & prop >= 0.04 ~ paste0(Level, "\n", n),
        TRUE ~ ""
      ),
      Tooltip = paste0(
        "Variable: ", as.character(Variable),
        "<br>Level: ", Level,
        "<br>Count: ", n,
        "<br>Percent: ", scales::percent(prop, accuracy = 0.1)
      )
    )

  # Build fill palette, with Missing always grey
  non_missing_keys <- plot_df %>%
    dplyr::filter(!IsMissing) %>%
    dplyr::pull(FillKey)

  non_missing_keys <- unique(as.character(non_missing_keys))

  fill_values <- stats::setNames(
    .SciDataColorValues(length(non_missing_keys)),
    non_missing_keys
  )

  missing_keys <- plot_df %>%
    dplyr::filter(IsMissing) %>%
    dplyr::pull(FillKey)

  missing_keys <- unique(as.character(missing_keys))

  if (length(missing_keys) > 0) {
    fill_values <- c(
      fill_values,
      stats::setNames(rep("grey70", length(missing_keys)), missing_keys)
    )
  }

  # Labels are drawn inside the bars, so their colour has to follow the fill
  # they sit on. The palette spans roughly 1.4:1 to 14:1 against black, so a
  # fixed label colour is illegible on part of it.
  plot_df <- plot_df %>%
    dplyr::mutate(
      LabelColor = .SciDataContrastText(
        fill_values[as.character(.data$FillKey)]
      )
    )

  x_lab <- if (LabelType == "percent") "Percent" else "Count"

  # Build outputs

  d <- ggplot2::ggplot(
    plot_df,
    ggplot2::aes(
      x = Variable,
      y = Value,
      fill = FillKey,
      text = Tooltip
    )
  ) +
    ggplot2::geom_col(
      position = if (LabelType == "percent") {
        ggplot2::position_fill(reverse = TRUE)
      } else {
        ggplot2::position_stack(reverse = TRUE)
      },
      width = 0.8,
      color = "white",
      linewidth = 0.3
    ) +
    ggplot2::geom_text(
      ggplot2::aes(label = Label, colour = LabelColor),
      position = if (LabelType == "percent") {
        ggplot2::position_fill(vjust = 0.5, reverse = TRUE)
      } else {
        ggplot2::position_stack(vjust = 0.5, reverse = TRUE)
      },
      size = 3,
      lineheight = 0.9,
      show.legend = FALSE
    ) +
    ggplot2::coord_flip() +
    ggplot2::scale_fill_manual(values = fill_values, drop = FALSE) +
    ggplot2::scale_colour_identity() +
    ggplot2::labs(
      x = NULL,
      y = x_lab,
      fill = NULL
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      legend.position = "none",
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major.y = ggplot2::element_blank()
    )

  if (LabelType == "percent") {
    d <- d + ggplot2::scale_y_continuous(
      labels = scales::percent_format(accuracy = 1)
    )
  }

  # Return result

  return(d)
}
