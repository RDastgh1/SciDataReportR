#' Plot ANOVA Relationships Matrix
#'
#' This function plots the relationship between continuous and categorical variables
#' using ANOVA or Kruskal-Wallis tests. It generates a "heatmap" with points
#' colored and shaped based on statistical significance and effect size. When
#' generalized eta-squared is unavailable, raw p-values are colored with
#' [scale_color_pvalue()]; the FDR-corrected plot uses adjusted p-values.
#'
#' @param data The data frame containing the variables of interest.
#' @param CatVars Character vector of categorical variable names.
#' @param ContVars Character vector of continuous variable names.
#' @param covariates Optional character vector of covariate names for ANCOVA analysis.
#' @param Relabel Logical indicating whether to relabel variables with their labels (default is TRUE).
#' @param Ordinal Logical, indicating whether ordinal variables should be considered.
#' @param Parametric Logical indicating whether to use parametric (ANOVA) or non-parametric (Kruskal-Wallis) tests (default is TRUE).
#' @param min_n Minimum number of complete observations required for a tested relationship.
#' @param eps Small positive value used to avoid zero-size plotting artifacts.
#' @return A list containing three ggplot objects: p (scatter plot without multiple comparison correction), p_FDR (scatter plot with FDR correction), and pvaltable (data frame of p-values and significance).
#' @import dplyr
#' @importFrom ggplot2 aes geom_point labs scale_shape_manual scale_colour_gradient guides theme
#' @importFrom sjlabelled get_label
#' @importFrom tidyr pivot_longer
#' @importFrom rstatix anova_test kruskal_test get_summary_stats add_significance adjust_pvalue
#' @importFrom stats na.omit var
#' @param fdr_scope Either `"matrix"` (default) or `"per_outcome"`, passed to
#'   [ApplyFDRCorrection()]. `"matrix"` corrects across all p-values at once
#'   (historical behavior). `"per_outcome"` corrects separately within each
#'   outcome: outcomes are the continuous variables (`ContVars`).
#' @section Parametric and non-parametric tests:
#' ANOVA assumes roughly normal residuals and similar variance across groups.
#' Biomarker concentrations are often right-skewed, and group sizes are often
#' uneven, both of which make the F-test unreliable.
#'
#' `Parametric = FALSE` switches to Kruskal-Wallis, which compares ranks rather
#' than means and assumes neither normality nor equal variance. The matrix is
#' built and read exactly the same way.
#'
#' Comparing the two p-value tables shows which conclusions depended on the
#' choice of test. Relationships that hold under both are the ones to trust.
#' Where they disagree, the direction is informative: significant only under
#' ANOVA suggests the result is being carried by skew or a few extreme values,
#' while significant only under Kruskal-Wallis suggests a real shift in the
#' bulk of the distribution that outliers were masking from the mean-based
#' test.
#'
#' Kruskal-Wallis is a rank test and has no ANCOVA form, so `covariates`
#' requires `Parametric = TRUE`.
#'
#' @param Data \strong{Deprecated} (since 19.15.0). Use \code{data} instead.
#' @param Covariates \strong{Deprecated} (since 19.15.0). Use \code{covariates} instead.
#' @examples
#' data(SampleData)
#' data(SampleVariableTypes)
#'
#' # Attach labels and factor levels for readable axes
#' Labelled <- RevalueData(SampleData, SampleVariableTypes)$RevaluedData
#'
#' result <- PlotAnovaRelationshipsMatrix(
#'   Labelled,
#'   CatVars = c("Diagnosis", "sex", "Genotype"),
#'   ContVars = c("age", "ACE_CD143_Angiotensin_Converti",
#'                "ACTH_Adrenocorticotropic_Hormon", "AXL", "Adiponectin",
#'                "Alpha_1_Antichymotrypsin", "Alpha_1_Antitrypsin",
#'                "Alpha_1_Microglobulin", "Alpha_2_Macroglobulin",
#'                "Apolipoprotein_A1")
#' )
#'
#' # Raw p-value associations
#' result$Unadjusted$plot
#'
#' # FDR-adjusted associations
#' result$FDRCorrected$plot
#'
#' # The same matrix using Kruskal-Wallis instead of ANOVA
#' result_NonParametric <- PlotAnovaRelationshipsMatrix(
#'   Labelled,
#'   CatVars = c("Diagnosis", "sex", "Genotype"),
#'   ContVars = c("age", "ACE_CD143_Angiotensin_Converti",
#'                "ACTH_Adrenocorticotropic_Hormon", "AXL", "Adiponectin",
#'                "Alpha_1_Antichymotrypsin", "Alpha_1_Antitrypsin",
#'                "Alpha_1_Microglobulin", "Alpha_2_Macroglobulin",
#'                "Apolipoprotein_A1"),
#'   Parametric = FALSE
#' )
#'
#' result_NonParametric$Unadjusted$plot
#' result_NonParametric$FDRCorrected$plot
#'
#' # Where the two tests disagree
#' cols_Key <- c("CategoricalVariable", "ContinuousVariable", "p")
#' df_Compare <- merge(
#'   result$Unadjusted$PvalTable[, cols_Key],
#'   result_NonParametric$Unadjusted$PvalTable[, cols_Key],
#'   by = c("CategoricalVariable", "ContinuousVariable"),
#'   suffixes = c("_ANOVA", "_KruskalWallis")
#' )
#' df_Compare$AgreesAt05 <-
#'   (df_Compare$p_ANOVA < 0.05) == (df_Compare$p_KruskalWallis < 0.05)
#'
#' htmltools::browsable(htmltools::HTML(as.character(
#'   FreezeTableHeader(
#'     dplyr::mutate(
#'       df_Compare,
#'       dplyr::across(dplyr::where(is.numeric), \(x) signif(x, 3))
#'     ),
#'     height = "320px", full_width = TRUE
#'   )
#' )))
#'
#' # Covariate adjustment (parametric only)
#' PlotAnovaRelationshipsMatrix(
#'   Labelled,
#'   CatVars = c("Diagnosis", "sex"),
#'   ContVars = c("AXL", "Adiponectin", "Alpha_1_Antitrypsin"),
#'   covariates = "age"
#' )$FDRCorrected$plot
#' @export
PlotAnovaRelationshipsMatrix <- function(data,
    CatVars,
    ContVars,
    covariates = NULL,
    Relabel = TRUE,
    Parametric = TRUE,
    Ordinal = FALSE,
    min_n = 4,
    eps = 1e-08,
    Data = lifecycle::deprecated(),
    fdr_scope = c("matrix", "per_outcome", "per_predictor"),
    Covariates = lifecycle::deprecated()) {
  # Deprecated argument shims (SciDataReportR 19.15.0)
  if (lifecycle::is_present(Data)) {
    lifecycle::deprecate_warn("19.15.0", "PlotAnovaRelationshipsMatrix(Data)", "PlotAnovaRelationshipsMatrix(data)")
    data <- Data
  }
  if (!missing(data)) Data <- data
  if (lifecycle::is_present(Covariates)) {
    lifecycle::deprecate_warn("19.15.0", "PlotAnovaRelationshipsMatrix(Covariates)", "PlotAnovaRelationshipsMatrix(covariates)")
    covariates <- Covariates
  }
  Covariates <- covariates
  fdr_scope <- match.arg(fdr_scope)


  method <- if (isTRUE(Parametric)) "Anova" else "Kruskal"

  # Supplied names must exist. Intersecting them away silently shrank the matrix
  # and, for covariates, produced unadjusted tests reported as adjusted.
  CatVars <- ScidrValidateVariables(Data, CatVars, "CatVars")
  ContVars <- ScidrValidateVariables(Data, ContVars, "ContVars")
  Covariates <- ScidrValidateVariables(Data, Covariates, "covariates")

  empty_return <- function() {
    empty <- data.frame()
    p0 <- ggplot2::ggplot(data.frame(x = 1, y = 1), ggplot2::aes(x, y)) +
      ggplot2::geom_blank() + ggplot2::theme_void()
    out <- list(
      Unadjusted = list(PvalTable = empty, plot = p0),
      FDRCorrected = list(PvalTable = empty, plot = p0),
      method = method, Relabel = Relabel, Covariates = Covariates
    )
    out$p <- out$Unadjusted
    out$p_fdr <- out$FDRCorrected
    out
  }

  if (length(CatVars) == 0 || length(ContVars) == 0) return(empty_return())

  # drop categorical vars with < 2 observed levels
  CatVars <- CatVars[vapply(CatVars, function(v) {
    x <- Data[[v]]
    x <- x[!is.na(x)]
    length(unique(x)) >= 2
  }, logical(1))]
  if (length(CatVars) == 0) return(empty_return())

  # continuous vars: must be numeric or coercible with enough non-NA + variance
  ContVars <- ContVars[vapply(ContVars, function(v) {
    x <- Data[[v]]
    if (!(is.numeric(x) || is.integer(x))) x <- suppressWarnings(as.numeric(as.character(x)))
    x <- x[is.finite(x)]
    if (length(x) < min_n) return(FALSE)
    vv <- stats::var(x, na.rm = TRUE)
    is.finite(vv) && vv > eps
  }, logical(1))]
  if (length(ContVars) == 0) return(empty_return())

  # covars: keep only non-constant and usable
  if (length(Covariates) > 0) {
    Covariates <- Covariates[vapply(Covariates, function(v) {
      z <- Data[[v]]
      z <- z[!is.na(z)]
      if (length(z) < min_n) return(FALSE)
      if (is.factor(z) || is.character(z)) return(length(unique(z)) >= 2)
      z2 <- suppressWarnings(as.numeric(as.character(z)))
      z2 <- z2[is.finite(z2)]
      if (length(z2) < min_n) return(FALSE)
      vv <- stats::var(z2, na.rm = TRUE)
      is.finite(vv) && vv > eps
    }, logical(1))]
  }

  vars_keep <- unique(c(CatVars, ContVars, Covariates))

  df0 <- Data %>%
    dplyr::select(dplyr::all_of(vars_keep)) %>%
    dplyr::mutate(.rowID = dplyr::row_number()) %>%
    dplyr::mutate(
      dplyr::across(
        dplyr::all_of(CatVars),
        function(x) if (is.factor(x)) factor(as.character(x), levels = levels(x)) else factor(x)
      )
    )

  # Keep covars attached by rowID (avoid pivot mixing types)
  cov_df <- if (length(Covariates) > 0) {
    df0 %>% dplyr::select(.rowID, dplyr::all_of(Covariates))
  } else {
    df0 %>% dplyr::select(.rowID)
  }

  mData <- df0 %>%
    tidyr::pivot_longer(
      cols = dplyr::all_of(CatVars),
      names_to = "CategoricalVariable",
      values_to = "CategoricalValue"
    ) %>%
    tidyr::pivot_longer(
      cols = dplyr::all_of(ContVars),
      names_to = "ContinuousVariable",
      values_to = "ContinuousValue"
    ) %>%
    dplyr::select(-dplyr::any_of(Covariates)) %>%
    dplyr::left_join(cov_df, by = ".rowID") %>%
    dplyr::mutate(
      CategoricalValue = as.factor(CategoricalValue),
      ContinuousVariable = as.factor(ContinuousVariable),
      ContinuousValue = suppressWarnings(as.numeric(as.character(ContinuousValue)))
    ) %>%
    tidyr::drop_na(CategoricalValue, ContinuousValue)

  if (length(Covariates) > 0) {
    mData <- tidyr::drop_na(mData, dplyr::all_of(Covariates))
  }

  if (nrow(mData) == 0) return(empty_return())

  # pair-level guards
  mData <- mData %>%
    dplyr::group_by(ContinuousVariable, CategoricalVariable) %>%
    dplyr::filter(
      dplyr::n() >= min_n,
      dplyr::n_distinct(CategoricalValue) > 1,
      dplyr::n_distinct(ContinuousValue) > 2,
      stats::sd(ContinuousValue, na.rm = TRUE) > eps
    ) %>%
    dplyr::ungroup()

  if (nrow(mData) == 0) return(empty_return())

  rhs <- "CategoricalValue"
  if (length(Covariates) > 0) rhs <- paste(rhs, paste(Covariates, collapse = " + "), sep = " + ")
  fml <- stats::as.formula(paste("ContinuousValue ~", rhs))

  safe_test_df <- function(df) {
    fit <- tryCatch(stats::lm(fml, data = df), error = function(e) NULL)
    if (is.null(fit)) return(NULL)
    rss <- sum(stats::resid(fit)^2)
    if (!is.finite(rss) || rss <= eps) return(NULL)

    out <- tryCatch({
      if (isTRUE(Parametric)) rstatix::anova_test(df, fml) else rstatix::kruskal_test(df, fml)
    }, error = function(e) NULL)

    if (is.null(out)) return(NULL)
    as.data.frame(out)  # strip classes
  }

  stat.test <- mData %>%
    dplyr::group_by(ContinuousVariable, CategoricalVariable) %>%
    dplyr::group_modify(~{
      res <- safe_test_df(.x)
      if (is.null(res)) return(tibble::tibble())
      tibble::as_tibble(res)
    }) %>%
    dplyr::ungroup()

  if (nrow(stat.test) == 0) return(empty_return())

  if (!("p" %in% names(stat.test)) && ("p.value" %in% names(stat.test))) {
    stat.test <- dplyr::rename(stat.test, p = p.value)
  }

  stat.test <- stat.test %>%
    rstatix::add_significance(p.col = "p", output.col = "p.signif")
  # Outcomes are the continuous variables (ContVars) for "per_outcome".
  stat.test$p.adj <- ApplyFDRCorrection(
    stat.test$p,
    fdr_scope = fdr_scope,
    outcome_ids = stat.test$ContinuousVariable,
    predictor_ids = stat.test$CategoricalVariable
  )
  stat.test <- stat.test %>%
    rstatix::add_significance(p.col = "p.adj", output.col = "p.adj.signif")

  stat.test$logp <- -log10(stat.test$p)
  stat.test$logp_FDR <- -log10(stat.test$p.adj)
  stat.test$`p<.05` <- factor(stat.test$p.signif, levels = c("ns","*","**","***","****"))
  stat.test$p.adj.signif <- factor(stat.test$p.adj.signif, levels = c("ns","*","**","***","****"))

  # Keep only main effect row if present
  if ("Effect" %in% names(stat.test)) {
    stat.test <- stat.test %>%
      dplyr::filter(Effect == "CategoricalValue")
  }

  # labels
  if (isTRUE(Relabel)) {
    Data <- ReplaceMissingLabels(Data)

    xlabels <- sjlabelled::get_label(Data[as.character(stat.test$CategoricalVariable)],
                                     def.value = stat.test$CategoricalVariable) %>%
      as.data.frame() %>%
      tibble::rownames_to_column()
    colnames(xlabels) <- c("Variable", "label")

    ylabels <- sjlabelled::get_label(Data[as.character(stat.test$ContinuousVariable)],
                                     def.value = stat.test$ContinuousVariable) %>%
      as.data.frame() %>%
      tibble::rownames_to_column()
    colnames(ylabels) <- c("Variable", "label")

    stat.test$XLabel <- xlabels$label
    stat.test$YLabel <- ylabels$label
  } else {
    stat.test$XLabel <- stat.test$CategoricalVariable
    stat.test$YLabel <- stat.test$ContinuousVariable
  }

  # ordering
  if (isTRUE(Relabel)) {
    stat.test$XLabel <- factor(stat.test$XLabel,
                               levels = sjlabelled::get_label(Data[as.character(CatVars)], def.value = CatVars))
    stat.test$YLabel <- factor(stat.test$YLabel,
                               levels = sjlabelled::get_label(Data[as.character(ContVars)], def.value = ContVars))
  } else {
    stat.test$XLabel <- factor(stat.test$XLabel, levels = CatVars)
    stat.test$YLabel <- factor(stat.test$YLabel, levels = ContVars)
  }

  stat.test$PlotText <- paste(
    "</br>Cat Var Label:", stat.test$XLabel,
    "</br>Cat Var:", stat.test$CategoricalVariable,
    "</br>Cont Var Label:", stat.test$YLabel,
    "</br>Cont Var:", stat.test$ContinuousVariable,
    "</br>P-Value:", stat.test$p, stat.test$p.signif,
    "</br>FDR P:", stat.test$p.adj, stat.test$p.adj.signif,
    if ("ges" %in% names(stat.test)) paste0("</br>GES:", stat.test$ges) else ""
  )

  stat.test <- stat.test %>%
    dplyr::mutate(Test = method) %>%
    as.data.frame()

  has_effect_size <- "ges" %in% names(stat.test)

  p <- ggplot2::ggplot(
    stat.test,
    ggplot2::aes(y = YLabel, x = XLabel, shape = `p<.05`, text = PlotText)
  ) +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 90),
      axis.title.x = ggplot2::element_blank(),
      axis.title.y = ggplot2::element_blank()
    ) +
    ggplot2::scale_shape_manual(values = c(7, 16, 17, 15, 18), drop = FALSE) +
    ggplot2::guides(size = "none") +
    ggplot2::labs(subtitle = "No Multiple Comparison Correction") +
    ggplot2::xlab("") +
    ggplot2::ylab("")

  if (has_effect_size) {
    p <- p +
      ggplot2::geom_point(
        ggplot2::aes(size = as.numeric(`p<.05`), colour = .data[["ges"]])
      ) +
      ggplot2::scale_colour_gradient(
      low = "#c6dbef",   # light blue
      high = "#08306b",  # dark blue
      name = "Effect Size"
    )
  } else {
    p <- p +
      ggplot2::geom_point(
        ggplot2::aes(size = as.numeric(`p<.05`), colour = .data[["p"]])
      ) +
      scale_color_pvalue()
  }

  p_FDR <- ggplot2::ggplot(
    stat.test,
    ggplot2::aes(y = YLabel, x = XLabel, shape = p.adj.signif, text = PlotText)
  ) +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 90),
      axis.title.x = ggplot2::element_blank(),
      axis.title.y = ggplot2::element_blank()
    ) +
    ggplot2::scale_shape_manual(values = c(7, 16, 17, 15, 18), drop = FALSE) +
    ggplot2::guides(size = "none") +
    ggplot2::labs(subtitle = "FDR Correction") +
    ggplot2::xlab("") +
    ggplot2::ylab("")

  if (has_effect_size) {
    p_FDR <- p_FDR +
      ggplot2::geom_point(
        ggplot2::aes(size = p.adj.signif, colour = .data[["ges"]])
      ) +
      ggplot2::scale_colour_gradient(
      low = "#c6dbef",   # light blue
      high = "#08306b",  # dark blue
      name = "Effect Size"
    )
  } else {
    p_FDR <- p_FDR +
      ggplot2::geom_point(
        ggplot2::aes(size = p.adj.signif, colour = .data[["p.adj"]])
      ) +
      scale_color_pvalue(name = "FDR-adjusted P-value")
  }

  out <- list(
    Unadjusted = list(PvalTable = stat.test, plot = p),
    FDRCorrected = list(PvalTable = stat.test, plot = p_FDR),
    method = method, Relabel = Relabel, Covariates = Covariates
  )
  # Standardized p-value element aliases (old names kept)
  out$p <- out$Unadjusted
  out$p_fdr <- out$FDRCorrected
  out
}
