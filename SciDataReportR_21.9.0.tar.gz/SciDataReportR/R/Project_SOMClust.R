
.NodeOccupancyJSD <- function(training_counts, projected_counts) {
  if (length(training_counts) != length(projected_counts)) {
    stop("training_counts and projected_counts must have the same length.")
  }
  if (!length(training_counts) || sum(training_counts) <= 0 || sum(projected_counts) <= 0) {
    return(NA_real_)
  }
  p <- training_counts / sum(training_counts)
  q <- projected_counts / sum(projected_counts)
  midpoint <- 0.5 * (p + q)
  0.5 * sum(ifelse(p > 0, p * log2(p / midpoint), 0)) +
    0.5 * sum(ifelse(q > 0, q * log2(q / midpoint), 0))
}

.SOMAssignedProbabilityPlot <- function(probability_data) {
  has_probability_spread <- nrow(probability_data) > 1L &&
    diff(range(probability_data$prob_assigned)) > 1e-06
  if (has_probability_spread) {
    return(
      ggplot2::ggplot(probability_data, ggplot2::aes(x = .data$prob_assigned)) +
        ggplot2::geom_density(fill = "darkblue", alpha = 0.7) +
        ggplot2::facet_wrap(~Cluster, scales = "free_y", nrow = 1) +
        ggplot2::coord_cartesian(xlim = c(0, 1)) +
        ggplot2::theme_bw() +
        ggplot2::labs(
          title = "Assigned posterior probability by cluster",
          x = "Posterior probability for assigned cluster", y = "Density"
        )
    )
  }
  ggplot2::ggplot(probability_data,
    ggplot2::aes(x = .data$prob_assigned, y = .data$Cluster)) +
    ggplot2::geom_rug(sides = "b", alpha = 0.65) +
    ggplot2::geom_point(alpha = 0.55,
      position = ggplot2::position_jitter(height = 0.08)) +
    ggplot2::coord_cartesian(xlim = c(0, 1)) +
    ggplot2::theme_bw() +
    ggplot2::labs(
      title = "Assigned posterior probability by cluster",
      subtitle = "Near-constant probabilities: a density cannot be estimated meaningfully",
      x = "Posterior probability for assigned cluster", y = "Cluster"
    )
}

#' Project new data onto an existing SOM clinical phenotype space
#'
#' @description
#' Train once, project many: a reusable unsupervised clinical phenotyping
#' framework that learns phenotype structure in a training cohort and projects
#' new participants into the fixed phenotype space while quantifying membership
#' uncertainty and projection fit. Given a fitted
#' \code{CreateClusterModel_SOM_MClust()}
#' object, project a new data frame onto:
#' \itemize{
#'   \item The same Z-score scaling (via SciDataReportR::ProjectZScore()) when
#'         the training object used computed or projected Z-scores.
#'   \item The same SOM (kohonen), using \code{kohonen::map()}.
#'   \item The same node-level latent profiles and posterior probabilities.
#' }
#'
#' If the training object used \code{ZScoreType = "PreZScored"}, this function
#' expects the new data already contains the same Z-score columns (by name)
#' stored in \code{object$ZScoreVars}. No re-zscoring is performed.
#'
#' For each projected case, the function:
#' \itemize{
#'   \item Assigns a SOM node and distance to BMU.
#'   \item Maps node-level cluster/posterior probabilities to the individual.
#'   \item Computes an overall SOM-distance z-score and flags:
#'     \itemize{
#'       \item \code{Flag_SOMDist_overallHigh} - distance > overall training p95.
#'       \item \code{Flag_SOMDist_clusterHigh} - distance > cluster-specific
#'             training p95 for that cluster.
#'     }
#' }
#'
#' Row alignment is preserved without adding internal identifier columns to
#' either the projected data or public diagnostics.
#'
#' Missing data:
#' \itemize{
#'   \item Only rows with complete Z-scores are mapped to the SOM.
#'   \item Rows with missing Z-scores receive NA for SOM_Node, SOM_Distance,
#'         and the cluster label.
#' }
#'
#' @param object A fitted SOM cluster model.
#' @param new_df Data frame of new cases to project.
#' @param ClusterVariableName Optional name for the cluster column; defaults to
#'   \code{object$ClusterVariableName}. If that column already exists in \code{new_df}
#'   it is overwritten (with a message).
#' @param high_dist_quantile Numeric value between 0 and 1 used to define
#'   high SOM-distance flags from the training distance distribution. Default
#'   is \code{0.95}.
#' @param low_prob_threshold Numeric posterior probability threshold used to
#'   flag uncertain phenotype membership. Default is \code{0.70}.
#'
#' @return A list of class \code{"Project_SOMClust"} with components:
#'   \itemize{
#'     \item \code{vars_used}, \code{ClusterVariableName}
#'     \item \code{DataWithClusters}: \code{new_df} with only the requested
#'           cluster and projection-fit columns appended.
#'     \item \code{ProbFit}: list with \code{node} (training node-level
#'           posterior info), \code{individual} (projected cluster assignments
#'           and posterior-probability diagnostics), and probability plots.
#'     \item \code{ProjectionFit}: full-length map-fit diagnostics, cohort and
#'           cluster summaries, training-support violations, policy, and plots.
#'     \item \code{ModelInfo_SOM}, \code{ModelInfo_MClust}: references to the
#'           original model objects for convenience.
#'   }
#'
#' @examples
#' \donttest{
#' data("SimulatedPhenotypeData")
#' df_Training <- dplyr::filter(SimulatedPhenotypeData, .data$Cohort == "Training")
#' df_Projection <- dplyr::filter(SimulatedPhenotypeData, .data$Cohort == "Projection")
#' model <- CreateClusterModel_SOM_MClust(
#'   data = df_Training,
#'   variables = paste0("Var", 1:12),
#'   method = "finalize",
#'   final_k = 4,
#'   final_model = 1,
#'   som_xdim = 5,
#'   som_ydim = 5,
#'   stability_resamples = 2,
#'   Relabel = FALSE,
#'   min_nodes_per_cluster = NULL
#' )
#' projected <- ProjectCluster(object = model, new_df = df_Projection)
#' head(projected$ProbFit$individual)
#' projected$ProjectionFit$plots$projection_fit_class_bar
#' projected$ProjectionFit$plots$som_grid_map
#' projected$ProbFit$plots$individual_ProbAssignedDensity
#' }
#' @noRd
#' @export
ProjectCluster.Pipeline_SOM_MClust <- function(
    object,
    new_df,
    ClusterVariableName = NULL,
    high_dist_quantile = 0.95,
    low_prob_threshold = 0.70,
    ...
) {


  if (!requireNamespace("kohonen", quietly = TRUE)) {
    stop("Package 'kohonen' is required.")
  }
  if (!requireNamespace("dplyr", quietly = TRUE) ||
      !requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Packages 'dplyr' and 'ggplot2' are required.")
  }


  if (!is.numeric(high_dist_quantile) || length(high_dist_quantile) != 1 ||
      is.na(high_dist_quantile) || high_dist_quantile <= 0 || high_dist_quantile >= 1) {
    stop("high_dist_quantile must be a single numeric value between 0 and 1.")
  }
  if (!is.numeric(low_prob_threshold) || length(low_prob_threshold) != 1 ||
      is.na(low_prob_threshold) || low_prob_threshold < 0 || low_prob_threshold > 1) {
    stop("low_prob_threshold must be a single numeric value between 0 and 1.")
  }

  vars_used <- object$vars_used
  if (is.null(ClusterVariableName)) {
    ClusterVariableName <- object$ClusterVariableName
  }


  missing_vars <- setdiff(vars_used, names(new_df))
  if (length(missing_vars) > 0) {
    stop(
      "new_df is missing required original training variable(s): ",
      paste(missing_vars, collapse = ", "),
      ". These variables are required so projected cohorts can be scaled and checked against the training range."
    )
  }

  training_variable_summary <- object$ModelInfo_SOM$ProjectionReference$training_variable_summary
  if (is.null(training_variable_summary)) {
    training_variable_summary <- object$ModelInfo_SOM$training_variable_summary
  }
  if (!is.null(training_variable_summary)) {
    out_of_range_summary <- training_variable_summary %>%
      dplyr::filter(.data$Variable %in% names(new_df)) %>%
      dplyr::rowwise() %>%
      dplyr::mutate(
        n_below_training_min = if (!is.numeric(new_df[[Variable]]) || is.na(min)) NA_integer_ else sum(new_df[[Variable]] < min, na.rm = TRUE),
        n_above_training_max = if (!is.numeric(new_df[[Variable]]) || is.na(max)) NA_integer_ else sum(new_df[[Variable]] > max, na.rm = TRUE),
        n_out_of_range = if (is.na(n_below_training_min) || is.na(n_above_training_max)) NA_integer_ else n_below_training_min + n_above_training_max,
        prop_out_of_range = if (is.na(n_out_of_range)) NA_real_ else n_out_of_range / sum(!is.na(new_df[[Variable]])),
        projected_min = if (!is.numeric(new_df[[Variable]]) || all(is.na(new_df[[Variable]]))) NA_real_ else min(new_df[[Variable]], na.rm = TRUE),
        projected_max = if (!is.numeric(new_df[[Variable]]) || all(is.na(new_df[[Variable]]))) NA_real_ else max(new_df[[Variable]], na.rm = TRUE)
      ) %>%
      dplyr::ungroup()
  } else {
    out_of_range_summary <- dplyr::tibble(
      Variable = vars_used,
      n_below_training_min = NA_integer_,
      n_above_training_max = NA_integer_,
      n_out_of_range = NA_integer_,
      prop_out_of_range = NA_real_,
      projected_min = NA_real_,
      projected_max = NA_real_
    )
  }

  out_of_range_vars <- out_of_range_summary %>%
    dplyr::filter(!is.na(.data$n_out_of_range), .data$n_out_of_range > 0) %>%
    dplyr::pull(.data$Variable)

  if (length(out_of_range_vars) > 0) {
    warning(
      "Projected data include values beyond the observed training range for: ",
      paste(out_of_range_vars, collapse = ", "),
      ". These cases are still mapped; review ProjectionFit$out_of_support."
    )
  }

  Flag_OutsideTrainingRange <- rep(FALSE, nrow(new_df))
  for (variable in out_of_range_vars) {
    bounds <- out_of_range_summary %>% dplyr::filter(.data$Variable == variable)
    values <- new_df[[variable]]
    Flag_OutsideTrainingRange <- Flag_OutsideTrainingRange |
      (!is.na(values) & (values < bounds$min[[1]] | values > bounds$max[[1]]))
  }

  # Stable row id ----------------------------------------------------------

  new_df_scidr <- .AddClusterRowID(new_df, "new_df")

  # Determine Z-score columns used in training -----------------------------

  ZScoreType_train <- object$ZScoreType
  ZScoreVars_used  <- object$ZScoreVars

  if (is.null(ZScoreVars_used)) {
    ZScoreVars_used <- paste0("Z_", vars_used)
  }

  # Z-score projection onto new_df -----------------------------------------

  if (!is.null(ZScoreType_train) && ZScoreType_train == "PreZScored") {

    missing_z <- setdiff(ZScoreVars_used, names(new_df_scidr))
    if (length(missing_z) > 0) {
      stop("new_df is missing required pre-zscored columns: ",
           paste(missing_z, collapse = ", "))
    }

    z_df_new <- new_df_scidr[, ZScoreVars_used, drop = FALSE]

    is_num_z <- vapply(z_df_new, is.numeric, logical(1))
    if (!all(is_num_z)) {
      stop("All PreZScored columns must be numeric. Non-numeric: ",
           paste(names(z_df_new)[!is_num_z], collapse = ", "))
    }

    complete_rows <- stats::complete.cases(z_df_new)
    if (!any(complete_rows)) {
      stop("No complete rows in new_df pre-zscored columns; cannot map to SOM.")
    }

    if (!identical(names(z_df_new), ZScoreVars_used)) {
      stop("Projected Z-score variable ordering does not match the training object.")
    }

    if (!identical(names(z_df_new), ZScoreVars_used)) {
      stop("Projected Z-score variable ordering does not match the training object.")
    }

    zmat_new <- as.matrix(z_df_new[complete_rows, , drop = FALSE])

  } else {

    if (!requireNamespace("SciDataReportR", quietly = TRUE)) {
      stop("SciDataReportR must be installed.")
    }

    Z_obj <- object$ZScoreObject
    if (is.null(Z_obj) || !"ZScoreObj" %in% class(Z_obj)) {
      stop("object$ZScoreObject must be a valid ZScoreObj from CreateClusterModel_SOM_MClust().")
    }

    z_proj <- SciDataReportR::ProjectZScore(
      data                 = new_df_scidr,
      variables          = vars_used,
      parameters         = Z_obj,
      ParameterInputType = "ZScoreObj",
      names_prefix       = "Z_"
    )

    z_df_new <- z_proj$ZScores

    missing_z <- setdiff(ZScoreVars_used, names(z_df_new))
    if (length(missing_z) > 0) {
      stop("Projected Z-scores are missing required columns: ",
           paste(missing_z, collapse = ", "))
    }

    z_df_new <- z_df_new[, ZScoreVars_used, drop = FALSE]

    complete_rows <- stats::complete.cases(z_df_new)
    if (!any(complete_rows)) {
      stop("No complete rows in new_df after Z-score projection; cannot map to SOM.")
    }

    zmat_new <- as.matrix(z_df_new[complete_rows, , drop = FALSE])
  }

  # Retrieve SOM / distance baselines from training ------------------------

  som_model <- object$ModelInfo_SOM$som_model

  SOMFit_train        <- object$ModelInfo_SOM$SOMFit
  dist_summary_train  <- SOMFit_train$distance_summary
  overall_mean        <- SOMFit_train$overall_mean
  overall_sd          <- SOMFit_train$overall_sd
  dist_by_cluster_tr  <- SOMFit_train$dist_by_cluster
  flag_by_cluster_tr  <- SOMFit_train$flag_by_cluster

  training_individual <- object$ProbFit$individual
  train_dist <- training_individual$SOM_Distance[!is.na(training_individual$SOM_Distance)]
  overall_high_cutoff <- as.numeric(stats::quantile(train_dist, high_dist_quantile, na.rm = TRUE))

  dist_by_cluster_cutoffs <- training_individual %>%
    dplyr::filter(!is.na(.data$SOM_Distance), !is.na(.data$Cluster)) %>%
    dplyr::group_by(.data$Cluster) %>%
    dplyr::summarise(
      train_cluster_high_cutoff = as.numeric(stats::quantile(.data$SOM_Distance, high_dist_quantile, na.rm = TRUE)),
      .groups = "drop"
    )

  # Map new data to SOM ----------------------------------------------------

  mapping <- kohonen::map(som_model, newdata = zmat_new)

  SOM_Node_new <- rep(NA_integer_, nrow(new_df_scidr))
  SOM_Node_new[complete_rows] <- mapping$unit.classif

  SOM_Dist_new <- rep(NA_real_, nrow(new_df_scidr))
  SOM_Dist_new[complete_rows] <- mapping$distances

  # Node-level info from training -----------------------------------------

  node_df <- object$ProbFit$node
  if (is.null(node_df)) {
    stop("object$ProbFit$node is missing; run CreateClusterModel_SOM_MClust() first.")
  }

  # Individual table with distance flags -----------------------------------

  individual_tbl <- dplyr::tibble(
    .row_id      = new_df_scidr$.row_id,
    SOM_Node     = SOM_Node_new,
    SOM_Distance = SOM_Dist_new
  ) %>%
    dplyr::left_join(node_df, by = c("SOM_Node" = "NodeID")) %>%
    dplyr::mutate(
      SOMDist_z_overall = if (is.finite(overall_sd) && overall_sd > 0)
        (SOM_Distance - overall_mean) / overall_sd else NA_real_,
      SOMDist_percentile_train = vapply(SOM_Distance, function(x) {
        if (is.na(x) || length(train_dist) == 0) NA_real_ else mean(train_dist <= x, na.rm = TRUE)
      }, numeric(1)),
      Flag_SOMDist_overallHigh =
        !is.na(SOM_Distance) & !is.na(overall_high_cutoff) & SOM_Distance > overall_high_cutoff,
      Flag_OutsideTrainingRange = Flag_OutsideTrainingRange
    ) %>%
    dplyr::left_join(
      dist_by_cluster_tr %>%
        dplyr::select(
          Cluster,
          train_mean_dist = mean,
          train_sd_dist   = sd,
          train_p90       = p90,
          train_p95       = p95,
          train_p99       = p99
        ),
      by = "Cluster"
    ) %>%
    dplyr::left_join(dist_by_cluster_cutoffs, by = "Cluster") %>%
    dplyr::mutate(
      Flag_SOMDist_clusterHigh =
        !is.na(SOM_Distance) & !is.na(train_cluster_high_cutoff) & SOM_Distance > train_cluster_high_cutoff,
      Projection_Fit_Class = dplyr::case_when(
        is.na(SOM_Distance) ~ NA_character_,
        (Flag_SOMDist_overallHigh | Flag_SOMDist_clusterHigh) &
          (is.na(max_prob) | max_prob < low_prob_threshold) ~ "Potential novel phenotype",
        Flag_SOMDist_overallHigh | Flag_SOMDist_clusterHigh ~ "Poor fit to training structure",
        !is.na(max_prob) & max_prob < low_prob_threshold ~ "Uncertain membership",
        TRUE ~ "Good fit"
      )
    )
  attr(individual_tbl$.row_id, "label") <- "Row ID"
  if (!is.null(object$id_var) && object$id_var %in% names(new_df_scidr)) {
    individual_tbl[[object$id_var]] <- new_df_scidr[[object$id_var]]
  }

  # DataWithClusters for projected data ------------------------------------

  DataWithClusters <- new_df_scidr

  if (ClusterVariableName %in% names(DataWithClusters)) {
    message("Column '", ClusterVariableName, "' already exists in new_df and will be overwritten.")
  }

  DataWithClusters[[ClusterVariableName]] <- individual_tbl$Cluster
  DataWithClusters$Projection_Fit_Class <- individual_tbl$Projection_Fit_Class

  # Frozen-SOM fit diagnostics for projected cases -------------------------

  somproj_tbl    <- individual_tbl
  somproj_non_na <- somproj_tbl[!is.na(somproj_tbl$SOM_Distance), ]

  dist_proj_summary <- stats::quantile(
    somproj_non_na$SOM_Distance,
    probs = c(0, 0.25, 0.5, 0.75, 0.95, 1),
    na.rm = TRUE
  )
  names(dist_proj_summary) <- c("min", "q25", "median", "q75", "p95", "max")

  flag_by_cluster_proj <- somproj_non_na %>%
    dplyr::filter(!is.na(Cluster)) %>%
    dplyr::group_by(Cluster) %>%
    dplyr::summarise(
      n_proj            = dplyr::n(),
      prop_overall_high = mean(Flag_SOMDist_overallHigh),
      prop_cluster_high = mean(Flag_SOMDist_clusterHigh),
      .groups = "drop"
    )

  distance_flag_comparison <- flag_by_cluster_proj %>%
    dplyr::left_join(
      flag_by_cluster_tr %>%
        dplyr::rename(
          n_train                 = n,
          train_prop_overall_high = prop_overall_high
        ),
      by = "Cluster"
    ) %>%
    dplyr::mutate(
      diff_prop_overall_high =
        prop_overall_high - train_prop_overall_high
    )

  max_train_prop <- max(flag_by_cluster_tr$prop_overall_high, na.rm = TRUE)
  max_proj_prop  <- max(flag_by_cluster_proj$prop_overall_high, na.rm = TRUE)

  if (is.finite(max_proj_prop) && max_proj_prop > max_train_prop) {
    warning(
      "At least one projected cluster has a higher proportion of high-distance ",
      "cases than any cluster in training (proj max = ",
      sprintf("%.1f%%", 100 * max_proj_prop),
      ", train max = ",
      sprintf("%.1f%%", 100 * max_train_prop),
      "). Review flags Flag_SOMDist_overallHigh / Flag_SOMDist_clusterHigh ",
      "in ProjectionFit$individual and ProjectionFit$by_cluster."
    )
  }


  train_node_occupancy <- SOMFit_train$node_occupancy %>%
    dplyr::mutate(cohort = "Training")

  proj_node_occupancy <- dplyr::tibble(
    NodeID = seq_len(nrow(object$ModelInfo_SOM$som_codes))
  ) %>%
    dplyr::left_join(
      as.data.frame(table(somproj_non_na$SOM_Node)) %>%
        dplyr::transmute(
          NodeID = as.integer(as.character(Var1)),
          n = as.integer(Freq)
        ),
      by = "NodeID"
    ) %>%
    dplyr::mutate(
      n = dplyr::if_else(is.na(.data$n), 0L, .data$n),
      cohort = "Projected"
    )

  all_nodes <- sort(unique(c(train_node_occupancy$NodeID, proj_node_occupancy$NodeID)))
  train_node_p <- train_node_occupancy %>%
    dplyr::right_join(dplyr::tibble(NodeID = all_nodes), by = "NodeID") %>%
    dplyr::mutate(n = dplyr::if_else(is.na(.data$n), 0L, .data$n)) %>%
    dplyr::arrange(.data$NodeID) %>%
    dplyr::pull(.data$n)
  proj_node_p <- proj_node_occupancy %>%
    dplyr::right_join(dplyr::tibble(NodeID = all_nodes), by = "NodeID") %>%
    dplyr::mutate(n = dplyr::if_else(is.na(.data$n), 0L, .data$n)) %>%
    dplyr::arrange(.data$NodeID) %>%
    dplyr::pull(.data$n)
  node_js <- .NodeOccupancyJSD(train_node_p, proj_node_p)

  training_mean_distance <- mean(train_dist, na.rm = TRUE)
  projected_mean_distance <- mean(somproj_non_na$SOM_Distance, na.rm = TRUE)
  training_median_distance <- stats::median(train_dist, na.rm = TRUE)
  projected_median_distance <- stats::median(somproj_non_na$SOM_Distance, na.rm = TRUE)

  distance_ratio <- projected_mean_distance / training_mean_distance
  phenotype_drift_index <- abs(log(distance_ratio))

  ProjectionDiagnostics <- dplyr::tibble(
    metric = c(
      "n_total",
      "n_complete",
      "n_missing",
      "training_mean_som_distance",
      "projected_mean_som_distance",
      "training_median_som_distance",
      "projected_median_som_distance",
      "mean_distance_ratio",
      "high_distance_burden",
      "cluster_high_distance_burden",
      "phenotype_drift_index",
      "node_occupancy_js_divergence"
    ),
    value = c(
      nrow(new_df_scidr),
      sum(complete_rows),
      sum(!complete_rows),
      training_mean_distance,
      projected_mean_distance,
      training_median_distance,
      projected_median_distance,
      distance_ratio,
      mean(somproj_non_na$Flag_SOMDist_overallHigh, na.rm = TRUE),
      mean(somproj_non_na$Flag_SOMDist_clusterHigh, na.rm = TRUE),
      phenotype_drift_index,
      node_js
    )
  )

  distance_compare_tbl <- dplyr::bind_rows(
    training_individual %>%
      dplyr::filter(!is.na(.data$SOM_Distance)) %>%
      dplyr::transmute(cohort = "Training", SOM_Distance = .data$SOM_Distance, Cluster = .data$Cluster),
    somproj_non_na %>%
      dplyr::transmute(cohort = "Projected", SOM_Distance = .data$SOM_Distance, Cluster = .data$Cluster)
  )

  p_dist_hist <- ggplot2::ggplot(
    somproj_non_na,
    ggplot2::aes(x = SOM_Distance)
  ) +
    ggplot2::geom_histogram(bins = 30) +
    ggplot2::theme_bw() +
    ggplot2::labs(
      title = "SOM distances (projected cases)",
      x     = "Distance to BMU",
      y     = "Count"
    )

  p_train_proj_dist_density <- ggplot2::ggplot(
    distance_compare_tbl,
    ggplot2::aes(x = SOM_Distance, fill = cohort)
  ) +
    ggplot2::geom_density(alpha = 0.35) +
    .SciDataFillScale() +
    ggplot2::theme_bw() +
    ggplot2::labs(
      title = "Training vs projected SOM distance",
      x = "Distance to BMU",
      y = "Density",
      fill = "Cohort"
    )

  qq_probs <- seq(0.01, 0.99, by = 0.01)
  qq_df <- dplyr::tibble(
    train_quantile = as.numeric(stats::quantile(train_dist, probs = qq_probs, na.rm = TRUE)),
    projected_quantile = as.numeric(stats::quantile(somproj_non_na$SOM_Distance, probs = qq_probs, na.rm = TRUE))
  )

  p_train_proj_dist_qq <- ggplot2::ggplot(
    qq_df,
    ggplot2::aes(x = .data$train_quantile, y = .data$projected_quantile)
  ) +
    ggplot2::geom_point() +
    ggplot2::geom_abline(slope = 1, intercept = 0) +
    ggplot2::theme_bw() +
    ggplot2::labs(
      title = "Training vs projected SOM distance QQ plot",
      x = "Training SOM distance quantile",
      y = "Projected SOM distance quantile"
    )

  cluster_fit_summary <- somproj_non_na %>%
    dplyr::filter(!is.na(.data$Cluster)) %>%
    dplyr::group_by(.data$Cluster) %>%
    dplyr::summarise(
      n = dplyr::n(),
      mean_distance = mean(.data$SOM_Distance, na.rm = TRUE),
      median_distance = stats::median(.data$SOM_Distance, na.rm = TRUE),
      mean_probability = mean(.data$prob_assigned, na.rm = TRUE),
      median_probability = stats::median(.data$prob_assigned, na.rm = TRUE),
      mean_distance_percentile = mean(.data$SOMDist_percentile_train, na.rm = TRUE),
      median_distance_percentile = stats::median(.data$SOMDist_percentile_train, na.rm = TRUE),
      prop_high_distance = mean(.data$Flag_SOMDist_overallHigh | .data$Flag_SOMDist_clusterHigh, na.rm = TRUE),
      prop_low_probability = mean(.data$prob_assigned < low_prob_threshold, na.rm = TRUE),
      prop_poor_fit = mean(.data$Projection_Fit_Class == "Poor fit to training structure", na.rm = TRUE),
      prop_potential_novel = mean(.data$Projection_Fit_Class == "Potential novel phenotype", na.rm = TRUE),
      .groups = "drop"
    )

  poor_fit_by_cluster <- cluster_fit_summary %>%
    dplyr::transmute(
      Cluster = .data$Cluster,
      n = .data$n,
      prop_poor_or_high_dist = .data$prop_high_distance,
      prop_potential_novel = .data$prop_potential_novel
    )

  p_projection_fit_class <- ggplot2::ggplot(
    somproj_non_na %>% dplyr::filter(!is.na(.data$Projection_Fit_Class)),
    ggplot2::aes(x = .data$Projection_Fit_Class)
  ) +
    ggplot2::geom_bar() +
    ggplot2::theme_bw() +
    ggplot2::labs(
      title = "Projected cases by projection fit class",
      x = "Projection fit class",
      y = "Count"
    )

  p_poor_fit_by_cluster <- ggplot2::ggplot(
    poor_fit_by_cluster,
    ggplot2::aes(x = factor(Cluster), y = prop_poor_or_high_dist)
  ) +
    ggplot2::geom_col() +
    ggplot2::theme_bw() +
    ggplot2::labs(
      title = "Poor-fit or high-distance projected cases by cluster",
      x = "Cluster",
      y = "Proportion"
    )

  DataWithClusters$Projection_Fit_Class <- individual_tbl$Projection_Fit_Class
  ProjectionFit <- list(
    individual = individual_tbl,
    summary = ProjectionDiagnostics,
    by_cluster = cluster_fit_summary,
    out_of_support = out_of_range_summary %>%
      dplyr::filter(!is.na(.data$n_out_of_range), .data$n_out_of_range > 0),
    policy = list(
    high_distance_quantile = high_dist_quantile,
    low_probability_threshold = low_prob_threshold,
    distance_metric = "distance to frozen SOM best-matching unit",
    range_policy = "Values beyond observed training minima or maxima are warned but mapped when complete"),
    plots = list(
      distance_hist = p_dist_hist,
      training_vs_projected_distance_density = p_train_proj_dist_density,
      training_vs_projected_distance_qq = p_train_proj_dist_qq,
      projection_fit_class_bar = p_projection_fit_class,
      poor_fit_by_cluster = p_poor_fit_by_cluster
    )
  )

  # ProbFit for projected cases --------------------------------------------

  probability_columns <- unique(c(
    ".row_id", object$id_var, "SOM_Node", "model_number", "classes_number",
    grep("^prob_", names(individual_tbl), value = TRUE),
    "Cluster", "max_prob", "prob_assigned", "uncertainty"
  ))
  probability_individual <- individual_tbl[, intersect(
    probability_columns, names(individual_tbl)), drop = FALSE]
  probability_plot_data <- probability_individual %>%
    dplyr::filter(!is.na(.data$Cluster), is.finite(.data$prob_assigned)) %>%
    dplyr::mutate(Cluster = factor(.data$Cluster))
  individual_ProbAssignedDensity <- .SOMAssignedProbabilityPlot(
    probability_plot_data)

  ProbFit <- list(
    node       = node_df,
    individual = probability_individual,
    plots      = list(
      individual_ProbAssignedDensity = individual_ProbAssignedDensity
    )
  )

  # Place projected cases on the frozen SOM grid, which is this pipeline's
  # native review space, so the map is comparable with the training figures.
  grid_points <- as.data.frame(object$ModelInfo_SOM$som_grid$pts)
  names(grid_points)[seq_len(min(2L, ncol(grid_points)))] <-
    c("SOM_X", "SOM_Y")[seq_len(min(2L, ncol(grid_points)))]
  grid_points$SOM_Node <- seq_len(nrow(grid_points))
  assignment_data <- dplyr::left_join(
    individual_tbl, grid_points, by = "SOM_Node")
  if (all(c("SOM_X", "SOM_Y") %in% names(assignment_data))) {
    ProjectionFit$plots$som_grid_map <- PlotClusterMap(
      dplyr::filter(assignment_data, !is.na(.data$SOM_X), !is.na(.data$SOM_Y)),
      "SOM_X", "SOM_Y", "Cluster",
      title = "Projected cases on the frozen SOM grid",
      subtitle = "Points are jittered within their best-matching unit",
      xlab = "SOM x", ylab = "SOM y") +
      ggplot2::geom_jitter(width = 0.12, height = 0.12, alpha = 0.65)
  }
  # aweSOM requires an SOM object carrying data and BMU assignments with the
  # same row count. This shallow copy is a display view only; the fitted SOM
  # remains frozen in the model object.
  if (requireNamespace("aweSOM", quietly = TRUE) && any(complete_rows)) {
    projection_som <- som_model
    projection_som$data[[1]] <- zmat_new
    projection_som$unit.classif <- mapping$unit.classif
    projection_som$distances <- mapping$distances
    projected_data <- new_df_scidr[complete_rows, vars_used, drop = FALSE]
    superclass <- node_df$Cluster
    ProjectionFit$plots$Circular <- aweSOM::aweSOMplot(
      projection_som, type = "Circular", data = projected_data,
      variables = vars_used, superclass = superclass)
    ProjectionFit$plots$Line <- aweSOM::aweSOMplot(
      projection_som, type = "Line", data = projected_data,
      variables = vars_used, superclass = superclass)
    ProjectionFit$plots$Cloud <- aweSOM::aweSOMplot(
      projection_som, type = "Cloud", data = projected_data,
      variables = c("None", vars_used), superclass = superclass,
      cloudSeed = 93421L)
  }

  out <- list(
    vars_used        = vars_used,
    ClusterVariableName      = ClusterVariableName,
    DataWithClusters = DataWithClusters,
    ProbFit          = ProbFit,
    ProjectionFit    = ProjectionFit,
    ModelInfo        = object$ModelInfo_MClust,
    ModelInfo_SOM    = object$ModelInfo_SOM,
    ModelInfo_MClust = object$ModelInfo_MClust
  )

  class(out) <- c("Project_SOMClust", class(out))
  out
}

#' @description Compatibility wrapper for [ProjectCluster()].
#' @rdname ProjectCluster
#' @param ... Arguments passed to [ProjectCluster()].
#' @export
Project_SOMClust <- function(...) {
  ProjectCluster(...)
}

#' @description Deprecated alias for [ProjectCluster()].
#' @rdname ProjectCluster
#' @export
ProjectSOMCluster <- function(...) {
  lifecycle::deprecate_warn("20.25.0", "ProjectSOMCluster()",
    "ProjectCluster()")
  ProjectCluster(...)
}
